//
//  NPIInterfaceConfiguration.h
//  Pia
//
//  Created by George Jingoiu on 06/08/2018.
//  Copyright © 2018 Nets. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "PiALanguage.h"

/**
 @NSObject NSObject that provides UI Customisation API
 */
@interface NPIInterfaceConfiguration : NSObject

/**
 Color to be used for all navigation bars.
 */
@property (nonatomic, strong) UIColor *barColor;

/**
 Color to be used for all navigation bars titles.
 */
@property (nonatomic, strong) UIColor *barTitleColor;

/**
 Color to be used for all navigation bars action items.
 */
@property (nonatomic, strong) UIColor *barItemsColor;

/**
 Color to be used for all UIViews that don't fit in any of the special casses below (navBar, label, field, switch, etc).
 */
@property (nonatomic, strong) UIColor *backgroundColor;

/**
 Font to be used for all buttons in the SDK. The point size will be overwritten, just the font name/familly will be used.
 */
@property (nonatomic, strong) UIFont  *buttonFont;

/**
 Title color to be used for all the buttons in the SDK for the default state.
 */
@property (nonatomic, strong) UIColor *buttonTextColor;

/**
 Title color to be used for all the buttons in the SDK for the default state.
 */
@property (nonatomic, strong) UIColor *mainButtonBackgroundColor;

/**
 Color for the switch thumbs.
 */
@property (nonatomic, strong) UIColor *switchThumbColor;

/**
 Color for the switch color when switch is on.
 */
@property (nonatomic, strong) UIColor *switchOnTintColor;

/**
 Color to be used in all fields/textviews in the SDK.
 */
@property (nonatomic, strong) UIColor *fieldTextColor;

/**
 Font to be used for all fields/textviews. The point size will be overwritten, just the font name/familly will be used.
 */
@property (nonatomic, strong) UIFont  *fieldFont;

/**
 Color to be used for all the labels in the SDK.
 */
@property (nonatomic, strong) UIColor *labelTextColor;

/**
 Color to be used in the error messages, border color of error text field and color of attention button on the text field.
 */
@property (nonatomic, strong) UIColor *errorFieldColor;

/**
 Color to be used in the successful validation case of card entry view.
 */
@property (nonatomic, strong) UIColor *successFieldColor;

/**
 Color to be used in CVC entry for Subsequent transaction view.
 */
@property (nonatomic, strong) UIColor *tokenCardCVCViewBackgroundColor;

/**
 Font to be used in the SDK for all labels. The point size will be overwritten, just the font name/familly will be used.
 */
@property (nonatomic, strong) UIFont  *labelFont;

/**
 Logo image to be displayed in the card form screen. Width equal to the screen, height = 70.
 */
@property (nonatomic, strong) UIImage  *logoImage;

/**
 Wheather or not the save card switch should be on by default.
 */
@property (nonatomic, readwrite) BOOL saveCardOn;

/**
 Color to be used for Card IO's background.
 */
@property (nonatomic, strong) UIColor *cardIOBackgroundColor;

/**
 Color to be used for Card IO's "Entry card manually" button text.
 */
@property (nonatomic, strong) UIColor *cardIOButtonTextColor;

/**
 Font to be used for Card IO's "Entry card manually" button font.
 */
@property (nonatomic, strong) UIFont *cardIOButtonTextFont;

/**
 Color to be used for Card IO's "Entry card manually" button background color.
 */
@property (nonatomic, strong) UIColor *cardIOButtonBackgroundColor;

/**
 Color to be used for Card IO preview frame.
 */
@property (nonatomic, strong) UIColor *cardIOPreviewFrameColor;

/**
 Color to be used for all the texts inside Card IO view.
 */
@property (nonatomic, strong) UIColor *cardIOTextColor;

/**
 Font to be used in the Card IO view for all labels. The point size will be overwritten, just the font name/familly will be used.
 */
@property (nonatomic, strong) UIFont *cardIOTextFont;

/**
 Choose whether to disable CardIO/Card scanner or not
 */
@property (nonatomic, readwrite) BOOL disableCardIO;

/**
 Color to be used for all view's status bar
 */
@property (nonatomic, strong) UIColor *statusBarColor;

/**
 Use either light or dark content for status bar
 */
@property (nonatomic, readwrite) BOOL useStatusBarLightContent;

/**
 Content view mode for logo image
 */
@property (nonatomic, readwrite) UIViewContentMode logoImageContentMode;

/**
 Choose whether to disable save card for later user option
 */
@property (nonatomic, readwrite) BOOL disableSaveCardOption;

/**
 Color to be used for all text entry background
 */
@property (nonatomic, strong) UIColor *fieldBackgroundColor;

/**
 Color to be used for all text entry background
 */
@property (nonatomic) PiALanguage language;

/**
 @return Singleton instance used throughout the code
 */
+ (instancetype) sharedInstance;

@end
