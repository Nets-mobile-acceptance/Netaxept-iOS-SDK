//
//  CardScheme.h
//  Pia
//
//  Created by Luke on 14.4.2021.
//  Copyright © 2021 Nets. All rights reserved.
//

#ifndef CardScheme_h
#define CardScheme_h

typedef NS_OPTIONS(NSUInteger, CardScheme) {
    CardSchemeNone                          = 0,
    CardSchemeAmex                          = 1 << 0,
    CardSchemeVisa                          = 1 << 1,
    CardSchemeMasterCard                    = 1 << 2,
    CardSchemeDinersClubInternational       = 1 << 3,
    CardSchemeJCB                           = 1 << 4,
    CardSchemeDankort                       = 1 << 5,
    CardSchemeMaestro                       = 1 << 6,
    CardSchemeSBusiness                     = 1 << 7
};

#endif /* CardScheme_h */
