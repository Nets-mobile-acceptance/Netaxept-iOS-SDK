//
//  PiaSDK.h
//  Pia
//
//  Created by Luke on 07/08/2019.
//  Copyright © 2019 Nets. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NPIError.h"

#import "PiaSDKController.h"

NS_ASSUME_NONNULL_BEGIN

@protocol WalletPaymentDelegate;
@protocol VippsPaymentDelegate;
@protocol SwishPaymentDelegate;
@protocol MobilePayDelegate;

typedef NSString * WalletURL;
typedef NSString * URLScheme;

@interface PiaSDK : NSObject

#pragma - mark Initiate Wallet Payment

/// Attempts to initiate Vipps payment and returns true if successful.
/// Returns false if Vipps is not installed or the URL scheme is missing under
/// `LSApplicationQueriesSchemes` in info.plist.
///
/// Payment flow including app-switch to and from Vipps is handled internally.
/// The default behaviour presents a transition view on `sender` during this transition.
/// To customize UI handling of app transition (to and from Vipps app), pass `nil` in
/// the `sender` view controller parameter and manage presentation of custom UI
/// (e.g. custom activity indicator) using the delegate calls.
///
/// @param sender The sender view controller. Used to present activity indicator during app switch
/// @param delegate The delegate responsible for handling the payment process.
/// @return True if Vipps app can be opened
///
+ (BOOL)initiateVippsFromSender:(UIViewController * _Nullable)sender delegate:(id<VippsPaymentDelegate>)delegate
__deprecated_msg("Use `initiateVippsFromSender: delegate: isTest:` instead.");

/// @param sender The sender view controller. Used to present activity indicator during app switch
/// @param delegate The delegate responsible for handling the payment process.
/// @param isTest is the payment in test mode
/// @return True if Vipps app can be opened
///
+ (BOOL)initiateVippsFromSender:(UIViewController * _Nullable)sender delegate:(id<VippsPaymentDelegate>)delegate isTest:(BOOL)isTest;



/// Attempts to initiate Swish payment and returns true if successful.
/// Returns false if Swish is not installed or the URL scheme is missing under
/// `LSApplicationQueriesSchemes` in info.plist.
///
/// Payment flow including app-switch to and from Swish is handled internally.
/// The default flow presents a transition view on `sender` during this transition.
/// To customize UI handling of app transition (to and from Swish app), pass `nil` in
/// the `sender` view controller parameter and manage presentation of custom UI
/// (e.g. custom activity indicator) using the delegate calls.
///
/// @param sender The sender view controller. Used to present activity indicator during app switch
/// @param delegate The delegate responsible for handling the payment process.
/// @return True if Swish app can be opened
///
+ (BOOL)initiateSwishFromSender:(UIViewController * _Nullable)sender delegate:(id<SwishPaymentDelegate>)delegate;

/// Attempts to initiate MobilePay payment and returns true if successful.
/// Returns false if MobilePay is not installed.
///
/// The default flow presents a transition view on `sender` during this transition.
/// To customize UI handling of app transition (to and from MobilePay app), pass `nil` in
/// the `sender` view controller parameter and manage presentation of custom UI
/// (e.g. custom activity indicator) using the delegate calls.
///
/// @param sender The sender view controller. Used to present activity indicator during app switch
/// @param delegate The delegate responsible for handling the payment process.
/// @param isTest is the payment in test mode
/// @return True if MobilePay app can be opened
///
+ (BOOL)initiateMobilePayFromSender:(UIViewController * _Nullable)sender delegate:(id<MobilePayDelegate>)delegate isTest:(BOOL)isTest;

/// Initiate payment with a stored card. If the payment requires 3DS authentication,
/// a webpage will be presented on the sender view controller.
///
/// It is recommended to show an activity indicator by passing `true` for `showsActivityIndicator`.
/// The same activity indicator can be presented using the API `showActivityIndicator(in:)`
/// while obtaining transaction ID from customer's merchant backend. The activity indicator will be
/// removed by the SDK before executing any of the completion blocks.
///
/// @param sender The `viewController` in which 3DS authentication is presented (if necessary)
/// @param isTestMode Is transaction to Netaxept test backend
/// @param showsActivityIndicator Show PiaSDK's standard activity indicator
/// @param merchantID Netaxept provided merchant ID
/// @param redirectURL Redirect URL used by 3DS to redirect user to the app
/// @param transactionID Transaction ID
/// @param success Success handler
/// @param cancellation Cancellation handler
/// @param failure Failure handler
///
+ (void)initiateTokenizedCardPayFrom:(UIViewController *)sender
                            testMode:(BOOL)isTestMode
              showsActivityIndicator:(BOOL)showsActivityIndicator
                          merchantID:(NSString *)merchantID
                         redirectURL:(NSString *)redirectURL
                       transactionID:(NSString *)transactionID
                             success:(void(^)(void))success
                        cancellation:(void(^)(void))cancellation
                             failure:(void(^)(NPIError * _Nonnull))failure;

#pragma - mark Redirect From Wallet App

/// Notify SDK app is opened from wallet app redirect.
/// @param redirectURL The redirect url received in `UIApplication:open url:options:`
/// @param options The options dictionary received in `UIApplication:open url:options:`
/// @return True if a redirect observer is registered with the SDK
///
/// @warning This API returns true as long as the SDK is expecting redirect. In the corner case where
///     the redirect URL is unrecognized (unknown to the SDK) while the SDK is waiting for
///     redirect from a wallet app, the API will return true and attempts to handle the redirect.
///     Use the new API `willHandleRedirectWith:(NSURL *)redirectURL andOptions:(NSDictionary *)options`
///     along with the correct "customer.redirect.scheme//piasdk?wallet=walletName" query during payment registration.
///
+ (BOOL)applicationDidOpenFromRedirectWith:(NSURL *)redirectURL andOptions:(NSDictionary *)options
__deprecated_msg("Use `willHandleRedirectWith:` instead. Make sure to add the wallet name during registration - `…//piasdk?wallet=walletName`");

/// Notify SDK that app is opened from wallet app redirect.
/// @param redirectURL The redirect url received in `UIApplication:open url:options:`
/// @param options The options dictionary received in `UIApplication:open url:options:`
/// @return True if a redirect observer is registered with the SDK for the given `redirectURL`.
///     Returns `false` if URL query "wallet" in `redirectURL` does not match expected wallet name.
///
+ (BOOL)willHandleRedirectWith:(NSURL *)redirectURL andOptions:(NSDictionary *)options;

/// Show PiaSDK's standard transition view. User interaction within the bounds of
/// the transition view is absorbed.
/// Pass `UIApplication.shared.keyWindow.rootViewController` in order to block user-
/// interaction even in navigation bar button items.
/// @param viewController The view controller where transition view is added
///
+ (void)showActivityIndicatorIn:(UIViewController *)viewController
__deprecated_msg("Use `addTransitionViewIn:` instead");

/// Remove PiaSDK's standard activity indicator. User interaction in the
/// given `viewController` will be enabled and the activity indicator removed
///
+ (void)removeActivityIndicatorFrom:(UIViewController * _Nullable)viewController
__deprecated_msg("Use `removeTransitionView` instead");

/// Show PiaSDK's standard transition view. User interaction within the bounds of
/// the transition view is absorbed.
/// Pass `UIApplication.shared.keyWindow.rootViewController` in order to block user-
/// interaction even in navigation bar button items.
/// @param superView Super view for SDK's standard transition view with activity indicator.
///
+ (void)addTransitionViewIn:(UIView *)superView;

/// Removes PiaSDK's standard transition view (if found).
+ (void)removeTransitionView;

@end

#pragma - mark WalletPaymentDelegate

/// Protocol common to wallet payments.
@protocol WalletPaymentDelegate<NSObject>

/// The wallet payment was successful. Commit the payment to finalize purchase.
///
/// Default behaviour keeps the transitionIndicatorView (activity indicator) animating.
/// @param transitionIndicatorView An activity indicator view (or nil) shown during transition.
///
- (void)walletPaymentDidSucceed:(nullable UIView *)transitionIndicatorView;

/// Wallet payment was interrupted.
///
/// Default behaviour keeps the transitionIndicatorView (activity indicator) animating.
/// @param transitionIndicatorView An activity indicator view (or nil) shown during transition.
///
- (void)walletPaymentInterrupted:(nullable UIView *)transitionIndicatorView;

@end

#pragma - mark VippsPaymentDelegate

/// Vipps status codes. Can be found on Vipps documentation.
///
/// - 302 User doesn’t have Vipps profile
///
/// - 303 Login failed (login max attempt reached)
///
/// - 304 Vipps doesn’t support this action, please update Vipps
///
/// - 401 Request timed out or Token has expired
///
/// - 451 The user was selected for fraud validation
///
/// - 999 Failed
///
typedef NSNumber * VippsStatusCode;

/// Vipps payment delegate is used by the SDK throughout Vipps payment process;
/// to obtain wallet URL from merchant BE and report payment status from Vipps app.
///
@protocol VippsPaymentDelegate<WalletPaymentDelegate>

/// Register Vipps payment with merchant backend. Callback with wallet URL
/// following successful registration.
/// @param completionWithWalletURL callback with retrieved wallet URL
/// @note Add "vipps" for query name "wallet" in the redirect URL passed to merchant backend.
///     e.g. "customer.redirect.scheme//piasdk?wallet=vipps"
///
- (void)registerVippsPayment:(void (^)(NSString * _Nullable))completionWithWalletURL;

/// Vipps payment failed with internal or Vipps error status.
/// The `VippsStatusCode` is nil if failure is internal.
///
/// Reasons for internal error include:
///
/// - Failure to open wallet app: not installed / the URL scheme is not registered.
///
/// - Invalid wallet URL (from payment registration response)
///
/// - Unknown redirect URL (UIApplication open:url redirect URL)
///
/// @param vippsStatusCode The status code returned from Vipps
///
- (void)vippsPaymentDidFailWith:(NPIError *)error
                vippsStatusCode:(nullable VippsStatusCode)vippsStatusCode;

@optional

/// (Optional) Returns the parsed raw status code from Vipps redirect.
/// Note: This delegate method is invoked while application is `inactive`.
/// Specific callbacks (success/failure) are followed after application
/// state has changed to `active`.
///
/// This optional method is intended to support custom transition UI needs
/// during app switch transitions.
///
/// @param statusCode Parsed Vipps status code
///
- (void)vippsDidRedirectWith:(VippsStatusCode)statusCode;

@end

#pragma - mark SwishPaymentDelegate

@protocol SwishPaymentDelegate<WalletPaymentDelegate>

/// Register Swish payment with merchant backend. Callback with wallet URL
/// following successful registration.
/// @param completionWithWalletURL callback with retrieved wallet URL
/// @note Add "swish" for query name "wallet" in the redirect URL passed to merchant backend.
///     e.g. "customer.redirect.scheme//piasdk?wallet=swish"
///
- (void)registerSwishPayment:(void (^)(NSString * _Nullable))completionWithWalletURL;

/// Wallet payment failed with internal error. Reasons for internal error include:
///
/// - Failure to open wallet app: wallet app uninstalled by user.
///
/// - Invalid wallet URL (from payment registration response)
///
/// - Unknown redirect URL (UIApplication open:url redirect URL)
///
/// @param error NPIError object with the specific error code.
///
- (void)swishPaymentDidFailWith:(NPIError *)error;

/// Notifies redirect from Swish or bank ID app (opened by Swish).
/// Commit the payment to obtain payment status and finalize purchase.
///
/// Default behaviour keeps the transitionIndicatorView (activity indicator) animating.
/// @param transitionIndicatorView An activity indicator view (or nil) shown during transition.
///
- (void)swishDidRedirect:(nullable UIView *)transitionIndicatorView;

@optional

/// Notifies redirect from Swish or bank ID app (opened by Swish).
/// Note: This delegate method is invoked while application is `inactive`.
/// Its followed by `swishDidRedirect:(UIView *)transitionIndicatorView`
/// after application state has changed to `active`.
///
/// This optional method is intended to support custom transition UI needs
/// during app switch transitions.
///
- (void)swishDidRedirect;

@end

#pragma - mark MobilePayDelegate

@protocol MobilePayDelegate<WalletPaymentDelegate>

/// Register MobilePay payment with merchant backend. Callback with wallet URL
/// following successful registration.
/// @param completionWithWalletURL callback with retrieved wallet URL
/// @note Add "mobilePay" for query name "wallet" in the redirect URL passed to merchant backend.
///     e.g. "customer.redirect.scheme//piasdk?wallet=mobilepay"
///
- (void)registerMobilePay:(void (^)(NSString * _Nullable))completionWithWalletURL;

/// Wallet payment failed with internal error. Reasons for internal error include:
///
/// - Failure to open wallet app: wallet app uninstalled by user.
///
/// - Invalid wallet URL (from payment registration response)
///
/// - Unknown redirect URL (UIApplication open:url redirect URL)
///
/// @param error NPIError object with the specific error code.
///
- (void)mobilePayDidFailWith:(NPIError *)error;

/// Notifies redirect from MobilePay.
/// Commit the payment to obtain payment status and finalize purchase.
///
/// Default behavior keeps the transitionIndicatorView (activity indicator) animating.
/// @param transitionIndicatorView An activity indicator view (or nil) shown during transition.
///
- (void)mobilePayDidRedirect:(nullable UIView *)transitionIndicatorView;

@optional

/// Notifies redirect from MobilePay.
/// Note: This delegate method is invoked while application is `inactive`.
/// Its followed by `mobilePayDidRedirect:(UIView *)transitionIndicatorView`
/// after application state has changed to `active`.
///
/// This optional method is intended to support custom transition UI needs
/// during app switch transitions.
///
- (void)mobilePayDidRedirect;

@end

NS_ASSUME_NONNULL_END
