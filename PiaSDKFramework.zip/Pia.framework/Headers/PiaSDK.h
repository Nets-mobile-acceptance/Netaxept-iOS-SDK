//
//  PiaSDK.h
//  Pia
//
//  Created by Luke on 07/08/2019.
//  Copyright © 2019 Nets. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NPIError.h"

NS_ASSUME_NONNULL_BEGIN

#pragma - mark PiaSDK

@protocol VippsPaymentDelegate;
@protocol WalletPaymentDelegate;

@interface PiaSDK : NSObject

/// Attempts to initiate Vipps payment and returns true if sucessful.
/// Returns false if Vipps is not installed or the URL scheme is missing under
/// `LSApplicationQueriesSchemes` in info.plist.
///
/// Payment flow including app-switch to and from Vipps is handled internally.
/// The default behaviour presents a transition view on `sender` during this transition.
/// To customize UI handling of app transition (to and from Vipps app), pass `nil` in
/// the `sender` view controller parameter and manage presentation of custom UI
/// (e.g. custom activity indicator) using the delegate calls.
///
/// @param sender The sender view controller. Used to present activity indicator during app switch
/// @param delegate The delegate responsible for handling the payment process.
/// @return True if Vipps app can be openned
+ (BOOL)initiateVippsFromSender:(UIViewController * _Nullable)sender delegate:(id<VippsPaymentDelegate>)delegate;

/// Notify SDK app is opened from wallet app redirect.
/// @param redirectURL The redirect url received in `UIApplication:open url:options:`
/// @param options The options dictionary received in `UIApplication:open url:options:`
///
+ (void)applicationDidOpenFromRedirectWith:(NSURL *)redirectURL andOptions:(NSDictionary *)options;

@end

#pragma - mark WalletPaymentDelegate

/// Protocol common to wallet payments.
@protocol WalletPaymentDelegate<NSObject>

/// The wallet payment was successful. Commit the payment to finalize purchase.
///
/// Default behaviour keeps the transitionIndicatorView (activity indicator) animating.
/// @param transitionIndicatorView An activity indicator view (or nil) shown during transition.
///
- (void)walletPaymentDidSucceed:(nullable UIView *)transitionIndicatorView;

/// Wallet payment was interrupted.
///
/// Default behaviour keeps the transitionIndicatorView (activity indicator) animating.
/// @param transitionIndicatorView An activity indicator view (or nil) shown during transition.
- (void)walletPaymentInterrupted:(nullable UIView *)transitionIndicatorView;

@end

#pragma - mark VippsPaymentDelegate

/// Vipps status codes. Can be found on Vipps documentation.
///
/// - 302 User doesn’t have Vipps profile
///
/// - 303 Login failed (login max attempt reached)
///
/// - 304 Vipps doesn’t support this action, please update Vipps
///
/// - 401 Request timed out or Token has expired
///
/// - 451 The user was selected for fraud validation
///
/// - 999 Failed
///
typedef NSNumber * VippsStatusCode;

/// Vipps payment delegate is used by the SDK throughout Vipps payment process;
/// to obtain wallet URL from merchant BE and report payment status from Vipps app.
///
@protocol VippsPaymentDelegate<WalletPaymentDelegate>

/// Register Vipps payment with merchant backend. Callback with wallet URL
/// following successful registration.
/// @param completionWithWalletURL callback with retreived wallet URL
///
- (void)registerVippsPayment:(void (^)(NSString * _Nullable))completionWithWalletURL;

/// Vipps payment failed with internal or Vipps error status.
/// The `VippsStatusCode` is nil if failure is internal.
///
/// Reasons for internal error include:
///
/// - Failure to open wallet app: not installed / the URL scheme is not registered.
///
/// - Invalid wallet URL (from payment registration response)
///
/// - Unknown redirect URL (UIApplication open:url redirect URL)
///
/// @param vippsStatusCode The status code returned from Vipps
///
- (void)vippsPaymentDidFailWith:(NPIError *)error
                vippsStatusCode:(nullable VippsStatusCode)vippsStatusCode;

@optional

/// (Optional) Returns the parsed raw status code from Vipps redirect.
/// Note: This delegate method is invoked while application is `inactive`.
/// Specific callbacks (success/failure) are followed after application
/// state has changed to `active`.
///
/// This optional method is intended to support custom transition UI needs
/// during app switch transitions.
///
/// @param statusCode Parsed Vipps status code
///
- (void)vippsDidRedirectWith:(VippsStatusCode)statusCode;

@end

NS_ASSUME_NONNULL_END
