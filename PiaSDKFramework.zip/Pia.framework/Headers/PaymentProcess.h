//
//  PaymentProcess.h
//  Pia
//
//  Created by Luke on 14.9.2020.
//  Copyright © 2020 Nets. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CardScheme.h"

NS_ASSUME_NONNULL_BEGIN

#pragma mark MerchantDetails

/// An object containing Netaxept provided merchant ID for test/production environment.
@interface MerchantDetails : NSObject
@property(nonatomic) NSString *merchantID;
@property(nonatomic) BOOL isTest;

- (instancetype)init NS_UNAVAILABLE;
+ (MerchantDetails *)merchantWithID:(NSString *)merchantID inTest:(BOOL)isTest;
@end

#pragma mark PaymentProcess (Abstract)

/// A namespace containing factories used to construct parameter list
/// required to initiate a given payment process.
@interface PaymentProcess : NSObject
@end

#pragma mark CardPaymentProcess (Abstract)

/// An abstract superclass for `CardStorage` and `CardPayment` processes.
@interface CardPaymentProcess : PaymentProcess
@property(nonatomic) MerchantDetails *merchant;
@property(readonly) CardScheme excludedCardSchemeSet;

- (instancetype)init NS_UNAVAILABLE;
@end

#pragma mark CardStorage

/// An object containing parameter list for card-storage process.
@interface CardStorage : CardPaymentProcess
@end

#pragma mark CardPayment

typedef NSString * Currency; // TODO: Check if this can be pre-defined list

/// An object containing parameter list for card-payment process.
@interface CardPayment : CardPaymentProcess
@property(nonatomic) NSUInteger amount;
@property(nonatomic) Currency currency;
@end

#pragma mark WalletPaymentProcess

typedef NS_CLOSED_ENUM(NSUInteger, Wallet) {
    WalletSwish,
    WalletVipps, WalletVippsTest,
    WalletMobilePay, WalletMobilePayTest
};

@interface WalletPaymentProcess : PaymentProcess
@property(nonatomic) Wallet wallet;
@property(nonatomic) BOOL showActivityIndicator;

- (instancetype)init NS_UNAVAILABLE;
@end


/// An object containing parameter list for paypal-payment process.
@interface PayPalPaymentProcess : PaymentProcess
@property(nonatomic) MerchantDetails *merchant;
- (instancetype)init NS_UNAVAILABLE;
@end

/// An object containing parameter list for paytrail-payment process.
@interface PaytrailPaymentProcess : PaymentProcess
@property(nonatomic) MerchantDetails * merchant;
- (instancetype)init NS_UNAVAILABLE;
@end

#pragma mark PaymentProcess + Factories

@interface PaymentProcess ()
/// Returns object containing required parameter list for card-storage process.
/// @param merchant The merchant details obtained from Netaxept
+ (CardStorage *)cardStorageWithMerchant:(MerchantDetails *)merchant;

/// Returns object containing required parameter list for card-storage process.
/// @param merchant The merchant details obtained from Netaxept
/// @param excludedCardSchemeSet Set of card schemes that should not be supported
+ (CardStorage *)cardStorageWithMerchant:(MerchantDetails *)merchant
                   excludedCardSchemeSet:(CardScheme)excludedCardSchemeSet;

/// Returns object containing required parameter list for card-payment process.
/// @param merchant The merchant details obtained from Netaxept
/// @param amount Amount of payment in cents
/// @param currency Currency code following iSO 4217
+ (CardPayment *)cardPaymentWithMerchant:(MerchantDetails *)merchant
                                  amount:(NSUInteger)amount
                                currency:(Currency)currency;

/// Returns object containing required parameter list for card-payment process.
/// @param merchant The merchant details obtained from Netaxept
/// @param excludedCardSchemeSet Set of card schemes that should not be supported
/// @param amount Amount of payment in cents
/// @param currency Currency code following iSO 4217
+ (CardPayment *)cardPaymentWithMerchant:(MerchantDetails *)merchant
                   excludedCardSchemeSet:(CardScheme)excludedCardSchemeSet
                                  amount:(NSUInteger)amount
                                currency:(Currency)currency;

/// Returns object containing required parameter list for wallet-payment process.
/// @param wallet A supported wallet by the SDK
+ (WalletPaymentProcess *)walletPaymentForWallet:(Wallet)wallet;

/// Returns object containing required parameter list for wallet-payment process.
/// @param wallet A supported wallet by the SDK
/// @param showActivityIndicator Pass `true` to show SDK standard activity indicator during the process.
+ (WalletPaymentProcess *)walletPaymentForWallet:(Wallet)wallet
                           showActivityIndicator:(BOOL)showActivityIndicator;

/// Returns object containing required parameter list for paypal payment process.
/// @param merchant The merchant details obtained from Netaxept
+ (PayPalPaymentProcess *)payPalPaymentWithMerchant:(MerchantDetails *)merchant;

/// Returns object containing required parameter list for paytrail payment process.
/// @param merchant The merchant details obtained from Netaxept
+ (PaytrailPaymentProcess *)paytrailPaymentWithMerchant:(MerchantDetails *)merchant;

// TODO: Factories for other payments

@end

NS_ASSUME_NONNULL_END
