//
//  PaymentRegistration.h
//  Pia
//
//  Created by Luke on 14.9.2020.
//  Copyright © 2020 Nets. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NPIError.h"
#import "NSError+Wallets.h"

NS_ASSUME_NONNULL_BEGIN

typedef NSURL * WalletURL;
typedef NSString * TransactionID;
typedef NSString * RedirectURL;

typedef NPIError * CardError; // TODO:

#pragma mark RegistrationResponse (Abstract)

@interface RegistrationResponse : NSObject
@property(nonatomic, nullable) NSError * error;
- (instancetype)init NS_UNAVAILABLE;
@end

#pragma mark WalletRegistrationResponse

@interface WalletRegistrationResponse : RegistrationResponse
@property(nonatomic) WalletURL walletURL;

- (instancetype)copy;

/// Return object containing response following successful registration with merchant backend.
+ (WalletRegistrationResponse *)successWithWalletURL:(WalletURL)walletURL;

/// Return object containing `error` following unsuccessful registration with merchant backend.
+ (WalletRegistrationResponse *)failure:(NSError * _Nullable)error;
@end

#pragma mark CardRegistrationResponse

@interface CardRegistrationResponse : RegistrationResponse
@property(nonatomic, nullable) TransactionID transactionID;
@property(nonatomic, nullable) RedirectURL redirectURL;

/// Return object containing response following successful registration with merchant backend.
+ (CardRegistrationResponse *)successWithTransactionID:(TransactionID)transactionID
                                           redirectURL:(RedirectURL)redirectURL;

/// Return object containing `error` following unsuccessful registration with merchant backend.
+ (CardRegistrationResponse *)failure:(NSError *)error;
@end

#pragma mark PayPalRegistrationResponse

@interface PayPalRegistrationResponse : RegistrationResponse
@property(nonatomic, nullable) TransactionID transactionID;
@property(nonatomic, nullable) RedirectURL redirectURL;

/// Return object containing response following successful registration with merchant backend.
+ (PayPalRegistrationResponse *)successWithTransactionID:(TransactionID)transactionID
                                           redirectURL:(RedirectURL)redirectURL;

/// Return object containing `error` following unsuccessful registration with merchant backend.
+ (PayPalRegistrationResponse *)failure:(NSError *)error;
@end

#pragma mark PaytrailRegistrationResponse

@interface PaytrailRegistrationResponse : RegistrationResponse
@property(nonatomic, nullable) TransactionID transactionID;
@property(nonatomic, nullable) RedirectURL redirectURL;

/// Return object containing response following successful registration with merchant backend.
+ (PaytrailRegistrationResponse *)successWithTransactionID:(TransactionID)transactionID
                                           redirectURL:(RedirectURL)redirectURL;

/// Return object containing `error` following unsuccessful registration with merchant backend.
+ (PaytrailRegistrationResponse *)failure:(NSError *)error;
@end

#pragma mark Callback Blocks

#define Escaping (^)
typedef void(^TransactionCallback)(BOOL, void Escaping (CardRegistrationResponse *));
typedef void(^PayPalRegistrationCallback)(void Escaping (PayPalRegistrationResponse *));
typedef void(^PaytrailRegistrationCallback)(void Escaping (PaytrailRegistrationResponse *));
typedef void(^WalletURLCallback)(void Escaping (WalletRegistrationResponse *));
typedef void(^WalletRedirectWithoutInterruption)(BOOL);
typedef void(^WalletFailureWithError)(WalletError);
typedef void(^CompletionCallback)(UIViewController *);
typedef void(^FailureCompletionCallback)(UIViewController *, CardError);

NS_ASSUME_NONNULL_END
